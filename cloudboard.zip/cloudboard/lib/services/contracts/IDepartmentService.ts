import { Department, DeptId } from '../types';

export interface IDepartmentService {
  getAllDepartments(): Promise<Department[]>;
  getDepartmentById(id: DeptId): Promise<Department | null>;
}
